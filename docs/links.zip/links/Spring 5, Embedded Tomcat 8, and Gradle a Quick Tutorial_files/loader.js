(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a=[0],b=[],c="//www.gstatic.com/call-tracking/call-tracking_2.js";if(window._googWcmAk){var d=parseInt(window._googWcmAk,10);-1===a.indexOf(d)&&(0<=b.indexOf(d)||0>d%100)&&(c="//www.gstatic.com/call-tracking/call-tracking_2.js")}var e=document.createElement("script");e.async=1;e.src=c;var f=document.getElementsByTagName("script")[0];e.setAttribute("nonce",f.nonce||f.getAttribute("nonce"));f.parentNode.insertBefore(e,f);}).call(this);
